# Ethiopic Primitives

Deterministic, model-free primitives for the Ethiopian calendar, fiscal periods,
Ge'ez numerals, and Ge'ez-script equivalence.

## Status

Pre-implementation. Fixtures and governance are in place; no library code yet.

## Why this exists

A prior-art survey found calendar conversion is implemented many times over, but:

| Library | Accuracy (measured) | Pagumē | Maintained |
|---|---|---|---|
| `py-ethiopian-date-converter` 0.1.1 | 16,801 / 16,801 days | correct | Mar 2025 |
| `ethiopian-date` 1.0 | arithmetic correct | **crashes** (322 days) | 2017 |
| Ethio-Intl (TS) | **48.9% of days wrong** | incorrect | dead 8 months |

Python is solved — depend on it, do not rebuild (Principle III). The gaps are
JS/TS conversion, **fiscal logic** (absent everywhere), and the **equivalence
engine** (absent everywhere).

## Repo layout

```
.specify/memory/constitution.md   governance — read this first
tests/vectors/calendar.json       182 vectors; 181 gating, ICU-corroborated
tools/reference_ethiopic.py       reference implementation
tools/check_provenance.py         Principle II gate
tools/full_sweep.py               Principle IX gate
```

## Working on this

```bash
python3 tools/check_provenance.py          # Principle II
python3 tools/full_sweep.py --from 1990 --to 2035   # Principle IX
```

Then in your agent: `/speckit-constitution`, `/speckit-specify`, `/speckit-plan`,
`/speckit-tasks`, `/speckit-implement`.

## Known blocker

No Tier-1 (Ethiopian government) source has been verified yet. ICU corroborates
181 vectors, but ICU shares a tabular-algorithm lineage with the reference — so
agreement is corroboration, not independence. **Principle II blocks public
release until a Tier-1 source is added.** Most tractable path: Negarit Gazeta
public-holiday proclamations giving Meskerem 1 across a decade.
